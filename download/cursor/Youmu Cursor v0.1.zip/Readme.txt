# Youmu Cursor v1.0
By @Cloverift
Note that "_Simple" Version has no transparency on it.

## Installation (Windows):
- Extract the cursor folder anywhere.
- Search and Open "main.cpl" without quotes on start menu. This will open Mouse Properties.
- Go to "Pointers" tab
- Change the cursor of your liking in the "Customize" section.

## Changelog
v1.0
Initial release